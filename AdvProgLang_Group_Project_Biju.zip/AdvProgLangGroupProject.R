##ADVANCED PROGRAMMING LANGUAGES GROUP PROJECT

#Return the current working directory of Advanced Programming Languages Group Project
getwd()

#Set the working directory for Advanced Programming Languages Group Project
setwd("C:/Users/amrit/Documents/AdvProgLang Group Project")

#Install the tidyverse, ggplot2, corrplot, caret, and superml packages with 
#the install.packages() command

install.packages("tidyverse")
install.packages("ggplot2")
install.packages("corrplot")
install.packages("caret")
install.packages("superml")
install.packages("glmnet")
install.packages("grf")


library(tidyverse)
library(ggplot2)
library(corrplot)
library(caret)
library(superml)
library(glmnet)
library(grf)

#SECTION 1

#DATA CLEANING

#A: Remove any duplicates and filter for unique values in the obesity.Rdata and 
#obesity_predict.Rdata 

#Sum the number of duplicate elements in obesity.Rdata and obesity_predict.Rdata 
sum(duplicated(obesity))
sum(duplicated(obesity_predict))


#Return the distinct elements present in obesity.Rdata and obesity_predict.Rdata
obesity %>% distinct()
obesity_predict %>% distinct()

#SEVENTEEN DUPLICATE ELEMENTS REMOVED IN OBESITY.RDATA 

#B:Identify any missing values and empty cells in obesity.Rdata and 
#obesity_predict.Rdata

#For obesity.Rdata and obesity_predict.Rdata, remove rows with NA's with the 
#drop_na() command
print(obesity %>% drop_na())
print(obesity_predict %>% drop_na())

#Return the sum of missing values present in obesity.Rdata and 
#obesity_predict.Rdata
sum(obesity=="")
sum(obesity_predict=="")

#NO MISSING VALUES & NA's

#Examine the structure and class of the obesity.Rdata to understand which of the
#sixteen variables must be transformed
str(obesity)

#C:Replicate obesityR.data in transform_obesity and numerically transform Gender,
#family_history_with_overweight, FAVC, CAEC, SMOKE, SCC, CALC, and MTRANS

transform_obesity=obesity
transform_obesity$Gender= as.numeric(factor(transform_obesity$Gender))
transform_obesity$family_history_with_overweight= as.numeric(factor(transform_obesity$
family_history_with_overweight))
transform_obesity$FAVC= as.numeric(factor(transform_obesity$FAVC))
transform_obesity$CAEC= as.numeric(factor(transform_obesity$CAEC))
transform_obesity$SMOKE= as.numeric(factor(transform_obesity$SMOKE))
transform_obesity$SCC= as.numeric(factor(transform_obesity$SCC))
transform_obesity$CALC= as.numeric(factor(transform_obesity$CALC))
transform_obesity$MTRANS= as.numeric(factor(transform_obesity$MTRANS))
transform_obesity

##C:Replicate obesity_predictR.data in transform_obesity_predict and numerically transform Gender,
#family_history_with_overweight, FAVC, CAEC, SMOKE, SCC, CALC, and MTRANS

transform_obesity_predict=obesity_predict
transform_obesity_predict$Gender= as.numeric(factor(transform_obesity_predict$Gender))
transform_obesity_predict$family_history_with_overweight= as.numeric(factor(transform_obesity_predict$
                                                                      family_history_with_overweight))
transform_obesity_predict$FAVC= as.numeric(factor(transform_obesity_predict$FAVC))
transform_obesity_predict$CAEC= as.numeric(factor(transform_obesity_predict$CAEC))
transform_obesity_predict$SMOKE= as.numeric(factor(transform_obesity_predict$SMOKE))
transform_obesity_predict$SCC= as.numeric(factor(transform_obesity_predict$SCC))
transform_obesity_predict$CALC= as.numeric(factor(transform_obesity_predict$CALC))
transform_obesity_predict$MTRANS= as.numeric(factor(transform_obesity_predict$MTRANS))
transform_obesity_predict

#D:Plot corrrelation matrix of transform_obesity with corrplot() command to 
#extract highly correlated variables 
corrplot(cor(transform_obesity), method = "circle")

#Examine pairs of correlated variables above 0.7 and below -0.7 in 
#transform_obesity
cormat=cor(transform_obesity)
diag(cormat)=0
cormat
highcor=cbind(unique(cormat[((cormat > 0.5)&(cormat < 1.0))])
              ,unique(cormat[(cormat < -0.5)]))
highcor
rownames(cormat)[which(cormat == highcor[1], arr.ind = TRUE)[1,]]
rownames(cormat)[which(cormat == highcor[2], arr.ind = TRUE)[1,]]

#NO PAIRS OF CORRELATED VARIABLES ABOVE 0.6 AND BELOW 0.6 
#highcor
#[,1]       [,2]
#[1,] 0.6104883 -0.5892182
# "Height" "Gender"
#"MTRANS" "Age"   

#BETWEEN +0.7/-0.7 NIL

#NO PAIRS OF HIGHLY CORRELATED VARIABLES IN TRANSFORM_OBESITY

#E: Inspect for outliers present in transform_obesity with relative frequency 
#histogram
histogram(transform_obesity$BMI, main='Frequency Histogram of transform_obesity',xlab='BMI',
          col="lavender")

#NO OUTLIERS IDENTIFIED

#F: For predictive purposes, the full rank condition must be fulfilled, that is
#the covariables in the numerically transformed transform_obesity are linearly
#independent
findLinearCombos(transform_obesity)

#NO LINEAR DEPENDENCE BETWEEN COVARIATES - FULL RANK CONDITION MET

####

#SECTION 2

#MACHINE LEARNING PREFERRED METHOD

#Set the seed, 56789, and define the composition of training and test data
#with the 85-15 split
set.seed(56789)

sample_size=floor(0.85*nrow(transform_obesity))
training_set=sample(seq_len(nrow(transform_obesity)), size = sample_size, replace = FALSE)

training_data=transform_obesity[training_set, ]
test_data=transform_obesity[-training_set, ]

##Random Forest

#Define the tuning parameters of the random forest
rep=900
cov=9
frac=1/2
min_obs=1

#Build and plot the random forest
set.seed(56789)

#Response variable in the random forest: BMI
y_obesity=as.matrix(transform_obesity[,16])

#Independent variables in the random forest: Gender, Age, Height, 
#family_history_with_overweight,FAVC, FCVC, NCP, CAEC, SMOKE, CH20, 
#SCC, FAF, TUE, CALC, and MTRANS
x_obesity=as.matrix(transform_obesity[, c(1:15)])

randomforest=regression_forest(x_obesity[training_set,], y_obesity[training_set,]
                               ,mtry = cov, sample.fraction = frac, num.trees = rep, 
                               min.node.size = min_obs, honesty = FALSE)
tree=get_tree(randomforest,1)
plot(tree)

#Calculate the out-of-sample mean squared error of the random forest
fit.randomforest=predict(randomforest, newdata=x_obesity[-training_set, ])$predictions
predMSE.randomforest=mean((test_data$BMI - fit.randomforest)^2)
print(paste("The out-of-sample mean squared error of the random forest is:",
            round(predMSE.randomforest,5)))

#"The out-of-sample mean squared error of the random forest is: 7.59211"

#Calculate the mean absolute error of the random forest 
predMAE.randomforest=mean(abs(test_data$BMI - fit.randomforest))
print(paste("The mean absolute error of the random forest is:",
            round(predMAE.randomforest,5)))

#"The mean absolute error of the random forest is: 1.82681"

#Calculate the R-squared of the random forest 
SST.randomforest=sum(((y_obesity[-training_set,])-mean((y_obesity[-training_set,])))^2)
SSE.randomforest=sum(((y_obesity[-training_set,])-fit.randomforest)^2)
R2.randomforest=1-SSE.randomforest/SST.randomforest
print(paste("The R-squared for the forest prediction is:",
            round(R2.randomforest,5)))

#The R-squared for the forest prediction is: 0.88959"

#Question 5

#Alternative Models

#METHOD OF PREDICTION 1: OLS 

#Alternative Model 1: Ordinary Least Sqaures (OLS) Estimates
ols=lm(BMI ~ ., data = training_data)
summary(ols)

#Calculate the out-of-sample mean squared error of the ordinary least squares estimate
fit.ols=predict(ols, newdata=test_data)
predMSE.ols=mean((test_data$BMI - fit.ols)^2)
print(paste("The out-of-sample mean squared error of the ordinary least squares estimate is:",
            round(predMSE.ols,5)))

#"The out-of-sample mean squared error of the ordinary least squares estimate is: 38.12822"

#Calculate the mean squared absolute error of the ordinary least squares estimate
predMAE.ols=mean(abs(test_data$BMI - fit.ols))
print(paste("The mean absolute error of the ordinary least squares estimate is:",
            round(predMAE.ols,5)))

#"The mean absolute error of the ordinary least squares estimate is: 5.04889"

#Calculate the R-squared of the ordinary least squares estimate
SST.ols=sum(((y_obesity[-training_set,])-mean((y_obesity[-training_set,])))^2)
SSE.ols=sum(((y_obesity[-training_set,])-fit.ols)^2)
R2.ols=1-SSE.ols/SST.ols
print(paste("The R-squared of the ordinary least squares estimate is:",
            round(R2.ols,5)))

#"The R-squared of the ordinary least squares estimate is: 0.44551"

#Alternative Model 2: Ordinary Least Sqaures (OLS) Estimates with First Order 
#Interactions
ols_foi=lm(BMI ~ (.)^2, data = training_data)
summary(ols_foi)

#Calculate the out-of-sample mean squared error of the ordinary least squares 
#estimate with first order interactions
fit.ols_foi=predict(ols_foi, newdata=test_data)
predMSE.ols_foi=mean((test_data$BMI - fit.ols_foi)^2)
print(paste("The out-of-sample mean squared error of the ordinary least squares estimate with first order interactions is:",
            round(predMSE.ols_foi,5)))

#"The out-of-sample mean squared error of the ordinary least squares estimate with first order interactions is: 25.35936"

#Calculate the mean squared absolute error of the ordinary least squares 
#estimate with first order interactions
predMAE.ols_foi=mean(abs(test_data$BMI - fit.ols_foi))
print(paste("The mean absolute error of the ordinary least squares estimate with first order interactions is:",
            round(predMAE.ols_foi,5)))

#"The mean absolute error of the ordinary least squares estimate with first order interactions is: 3.65192"

#Calculate the R-squared of the ordinary least squares estimate with first order 
#interactions
SST.ols_foi=sum(((y_obesity[-training_set,])-mean((y_obesity[-training_set,])))^2)
SSE.ols_foi=sum(((y_obesity[-training_set,])-fit.ols_foi)^2)
R2.ols_foi=1-SSE.ols_foi/SST.ols_foi
print(paste("The R-squared of the ordinary least squares estimate with first order interactions is:",
            round(R2.ols_foi,5)))

#"The R-squared of the ordinary least squares estimate with first order interactions is: 0.63121"

#Alternative Model 3: Ordinary Least Sqaures (OLS) Estimates with Five-Fold Cross Validation
library(caret)
train.control5=trainControl(method = "cv", number = 5)

set.seed(56789)

ols.5CV=train(BMI ~ ., data = training_data,
              method = "lm", trControl = train.control5)
ols.5CV

#Calculate the mean squared error of the OLS estimate with five-fold cross validation
predMSE.ols5CV=ols.5CV$results$RMSE^2
print(paste("The mean squared error of the ordinary least squares estimate with five-fold cross validation is:",
            round(predMSE.ols5CV,5)))

#"The mean squared error of the ordinary least squares estimate with five-fold cross validation is: 35.24009"

#Calculate the mean absolute error of the OLS estimate with five-fold cross validation
predMAE.ols5CV=ols.5CV$results$MAE
print(paste("The mean absolute error of the ordinary least squares estimate with five-fold cross validation is:",
            round(predMAE.ols5CV,5)))

#"The mean absolute error of the ordinary least squares estimate with five-fold cross validation is: 4.80177"

#Calculate the mean absolute error of the OLS estimate with five-fold cross validation
R2.ols5CV=ols.5CV$results$Rsquared
print(paste("The R-sqaured of the ordinary least squares estimate with five-fold cross validation is:",
            round(R2.ols5CV,5)))

#"The R-sqaured of the ordinary least squares estimate with five-fold cross validation is: 0.45137"

#Alternative Model 4: Ordinary Least Sqaures (OLS) Estimates with Ten-Fold Cross Validation
library(caret)
train.control10=trainControl(method = "cv", number = 10)

set.seed(56789)
ols.10CV=train(BMI ~ ., data = training_data,
               method = "lm", trControl = train.control10)
ols.10CV

#Calculate the out-of-sample mean squared error of the OLS estimate with ten-fold cross validation
predMSE.ols10CV=ols.10CV$results$RMSE^2
print(paste("The out-of-sample mean squared error of the ordinary least squares estimate with ten-fold cross validation is:",
            round(predMSE.ols10CV,5)))

#"The out-of-sample mean squared error of the ordinary least squares estimate with ten-fold cross validation is: 35.28392"

#Calculate the mean absolute error of the OLS estimate with ten-fold cross validation
predMAE.ols10CV=ols.10CV$results$MAE
print(paste("The mean squared absolute error of the ordinary least squares estimate with ten-fold cross validation is:",
            round(predMAE.ols10CV,5)))

#"The mean squared absolute error of the ordinary least squares estimate with ten-fold cross validation is: 4.80888"

#Calculate the R-squared of the OLS estimate with ten-fold cross validation
R2.ols10CV=ols.10CV$results$Rsquared
print(paste("The R-sqaured of the ordinary least squares estimate with ten-fold cross validation is is:",
            round(R2.ols10CV,5)))

#"The R-sqaured of the ordinary least squares estimate with ten-fold cross validation is is: 0.45357"

#METHOD OF PREDICTION 2: Ridge Regression with Ten-Fold Cross Validation 
set.seed(56789)
ridge.cv=cv.glmnet(as.matrix(training_data[,c(1:15)]),training_data$BMI,
                   type.measure="mse",family="gaussian",nfolds=10,alpha=0)
coef_ridge=coef(ridge.cv,s="lambda.min")
print(coef_ridge)

#Calculate the out-of-sample mean squared error of the ridge regression coefficient estimate
fit.ridge10CV=predict(ridge.cv,newx=as.matrix(test_data[,c(1:15)]),
                     s=ridge.cv$lambda.min)
predMSE.ridge10CV=mean((test_data$BMI-fit.ridge10CV)^2)
print(paste("The out-of-sample mean squared error of the ridge regression with ten-fold cross validation is:",
            round(predMSE.ridge10CV,5)))

# "The out-of-sample mean squared error of the ridge regression with ten-fold cross validation is: 37.96877"

#Calculate the mean absolute error of the ridge regression coefficient estimate 
predMAE.ridge10CV=mean(abs(test_data$BMI - fit.ridge10CV))
print(paste("The mean absolute error of the ridge regression with ten-fold cross validation is:",
            round(predMAE.ridge10CV,5)))

#"The mean absolute error of the ridge regression with ten-fold cross validation is: 5.0628"

#Calculate the R-squared of the ridge regression coefficient estimate
SST.ridge10CV=sum(((y_obesity[-training_set,])-mean((y_obesity[-training_set,])))^2)
SSE.ridge10CV=sum(((y_obesity[-training_set,])-fit.ridge10CV)^2)
R2.ridge10CV=1-SSE.ridge10CV/SST.ridge10CV
print(paste("The R-squared of the ridge regression with ten-fold cross validation is:",
            round(R2.ridge10CV,5)))

#"The R-squared of the ridge regression estimate with ten-fold cross validation is: 0.44783"

#METHOD OF PREDICTION 3:  Least Squares Absolute Selection & Shrinkage Operator (LASSO) 
#with Ten-Fold Cross Validation
set.seed(56789)
lasso.10CV=cv.glmnet(as.matrix(training_data[,c(1:15)]),training_data$BMI,
                   type.measure="mse",family="gaussian",nfolds=10,alpha=1)
coef_lasso=coef(lasso.10CV,s="lambda.min")
print(coef_lasso)

#Calculate the out-of-sample mean squared error of the lasso coefficient estime
fit.lasso10CV=predict(lasso.10CV,newx=as.matrix(test_data[,c(1:15)]),
                     s=lasso.10CV$lambda.min)
predMSE.lasso10CV=mean((test_data$BMI-fit.lasso10CV)^2)
print(paste("The out-of-sample mean squared error of the lasso with ten-fold cross validation is:",
            round(predMSE.lasso10CV,5)))

#"The out-of-sample mean squared error of the lasso with ten-fold cross validation is: 38.05431"

#Calculate the mean absolute error of the lasso coefficient estimate 
predMAE.lasso10CV=mean(abs(test_data$BMI - fit.lasso10CV))
print(paste("The mean absolute error of the lasso with ten-fold cross validation is:",
            round(predMAE.lasso10CV,5)))

#"The mean absolute error of the lasso with ten-fold cross validation is: 5.04867"

#Calculate the R-squared of the lasso coefficient estimate
SST.lasso10CV=sum(((y_obesity[-training_set,])-mean((y_obesity[-training_set,])))^2)
SSE.lasso10CV=sum(((y_obesity[-training_set,])-fit.lasso10CV)^2)
R2.lasso10CV=1-SSE.lasso10CV/SST.lasso10CV
print(paste("The R-squared of the lasso with ten-fold cross validation is:",
            round(R2.lasso10CV,5)))

#"The R-squared of the lasso with ten-fold cross validation is: 0.44659"

results.table=data.frame('MSE' = c(predMSE.ols, predMSE.ols_foi, predMSE.ols5CV, predMSE.ols10CV,predMSE.ridge10CV, predMSE.lasso10CV, predMSE.randomforest),
                         'MAE' = c(predMAE.ols, predMAE.ols_foi, predMAE.ols5CV, predMAE.ols10CV,predMAE.ridge10CV,predMAE.lasso10CV, predMAE.randomforest),
                         'R2' = c(R2.ols, R2.ols_foi, R2.ols5CV, R2.ols10CV,R2.ridge10CV, R2.lasso10CV, R2.randomforest))
rownames(results.table)=c("OLS", "OLS with First Order Interactions", "OLS with Five-Fold Cross Validation","OLS with Ten-Fold Cross Validation", "Ridge with Ten-Fold Cross Validation","LASSO with Ten-Fold Cross Validation",
                          "Random Forest")
results.table


#Predictions
results=predict(randomforest, newdata=transform_obesity_predict)
write.csv(results, "obesity_prediction.csv", row.names = FALSE)






